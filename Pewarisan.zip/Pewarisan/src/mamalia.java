/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class mamalia {
    
    //variabel
   String nafas="paru-paru";
   String tulang="vertebrata";
   
   
    //fungsi
  void bernafas () {
  System.out.println("mamalia bernafas dengan : " +nafas);
  
  }
  
   void tulang () {
  System.out.println("mamalia berjenis tulang : " +tulang);
  
  }
          
          
    
}
