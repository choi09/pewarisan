/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class monyet extends mamalia{
    
    //variabel
   String habitat="darat";
   
    //fungsi
  void habitat () {
  System.out.println("monyet mempunyai habitat di :" +habitat);
  
  }
    
    
    
}
